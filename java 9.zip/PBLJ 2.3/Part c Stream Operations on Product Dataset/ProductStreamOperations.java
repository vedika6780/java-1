import java.util.*;
import java.util.stream.*;
import java.util.Comparator;
import java.util.Map;
import java.util.Optional;

class Product {
    String name;
    double price;
    String category;

    Product(String name, double price, String category) {
        this.name = name;
        this.price = price;
        this.category = category;
    }

    public String toString() {
        return name + " - " + category + " - $" + price;
    }
}

public class ProductStreamOperations {
    public static void main(String[] args) {
        List<Product> products = Arrays.asList(
            new Product("Laptop", 1200, "Electronics"),
            new Product("Phone", 800, "Electronics"),
            new Product("TV", 1500, "Electronics"),
            new Product("Shirt", 40, "Clothing"),
            new Product("Jeans", 60, "Clothing"),
            new Product("Blender", 100, "Home Appliances"),
            new Product("Oven", 200, "Home Appliances")
        );

        System.out.println("Products Grouped by Category:");
        Map<String, List<Product>> grouped = products.stream()
            .collect(Collectors.groupingBy(p -> p.category));
        grouped.forEach((cat, prodList) -> {
            System.out.println(cat + ": " + prodList);
        });

        System.out.println("\nMost Expensive Product in Each Category:");
        Map<String, Optional<Product>> maxByCategory = products.stream()
            .collect(Collectors.groupingBy(p -> p.category,
                    Collectors.maxBy(Comparator.comparingDouble(p -> p.price))));
        maxByCategory.forEach((cat, prod) -> {
            System.out.println(cat + ": " + prod.get());
        });

        double avgPrice = products.stream()
            .collect(Collectors.averagingDouble(p -> p.price));
        System.out.println("\nAverage Price of All Products: $" + avgPrice);
    }
}
